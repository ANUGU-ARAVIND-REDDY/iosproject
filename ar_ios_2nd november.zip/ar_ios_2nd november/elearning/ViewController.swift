//
//  ViewController.swift
//  elearning
//
//  Created by Student on 12/10/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
   
    
    @IBOutlet weak var username: UITextField!
    
    
    @IBOutlet weak var password: UITextField!
    @IBAction func login(_ sender: Any) {
        if(username.text=="anuguarvindreddy456@gmail.com" && password.text=="1234"){
            performSegue(withIdentifier: "login", sender: self)
        }
        else{
            let okHandler1 = {
                (action: UIAlertAction)->Void in
            }
            let alert=UIAlertController(title: "warning", message: "No User Found", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title:"OK", style: .default, handler: okHandler1))
            alert.addAction(UIAlertAction(title:"CANCEL", style: .default, handler: okHandler1))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    @IBAction func signup(_ sender: Any) {
        
        performSegue(withIdentifier: "signup", sender: self)
    }
    
    
    
    @IBAction func FB(_ sender: Any) {
        
        performSegue(withIdentifier: "FB", sender: self)
        
    }
    
    @IBAction func forgotpass(_ sender: Any) {
        
        performSegue(withIdentifier: "forgotpass", sender: self)
    }
    
    @IBAction func google(_ sender: Any) {
        
        performSegue(withIdentifier: "google", sender: self)
    }
}

